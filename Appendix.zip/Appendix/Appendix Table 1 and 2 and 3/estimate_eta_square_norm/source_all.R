

source("estimate_kappa1_delta_2_kappa1_0.5.R")
source("estimate_kappa1_delta_2_kappa1_1.R")
source("estimate_kappa1_delta_2_kappa1_2.R")
source("estimate_kappa1_delta_2_kappa1_1.5.R")

source("estimate_kappa1_delta_4_kappa1_0.5.R")
source("estimate_kappa1_delta_4_kappa1_1.R")
source("estimate_kappa1_delta_4_kappa1_2.R")
source("estimate_kappa1_delta_4_kappa1_1.5.R")
