library(MASS)
library(glmnet)
library(parallel)
numCores=min(50,detectCores())
library(Rcpp)
library(RcppEigen)
options(rcpp.warnNoExports = FALSE)
sourceCpp("estimate_VE_Eigencpp.cpp")

tau_0_seq=seq(0.1,4,0.1)
generate_beta<-function(p,kappa1,beta_true_gen="normal"){
  if(beta_true_gen=="normal"){
    return(rnorm(p,sd=kappa1))
  }
  if(beta_true_gen=="uniform"){
    return(runif(p,min=-1,max=1)*kappa1*sqrt(3))
  }
  if(beta_true_gen=="t3"){
    return(rt(p,df=3)*kappa1/sqrt(3))
  }
  if(beta_true_gen=="halfsparse"){
    ind <- sample(c(TRUE, FALSE), p, replace = TRUE)
    v=rnorm(p,sd=kappa1*sqrt(2))
    v[ind]=0
    return(v)
  }
}

# leave one out cross validation ------------------------------------------

loocv_best_tau<-function(X,Y,Xstar,Ystar,tau_0_seq){
  p=ncol(X)
  n=length(Y)
  M=length(Ystar)
  ve_error=rep(0,length(tau_0_seq))
  for(tau_0_index in 1:length(tau_0_seq)){
    tau_0=tau_0_seq[tau_0_index]
    fit_cat_tau_0=glmnet(rbind(X,Xstar),c(Y,Ystar),weights =c(rep(1,n),rep(tau_0*n/M,M)) ,
                         family = "binomial",alpha=0,lambda = 0,intercept = FALSE,standardize = FALSE)
    betahat_tau0=as.numeric(fit_cat_tau_0$beta)
    ve_error[tau_0_index]=estimate_VELOOCV_cpp(X,Y,Xstar,Ystar,tau_0,betahat_tau0)
  }
  return(tau_0_seq[which.min(ve_error)])
}
get_sd_stdnormal<-function(ddd){
  sigma_seq=seq(0.1,10,by=0.02)
  target_index=which.min(abs(pnorm(IQR(ddd)/2,mean=0,sd=sigma_seq)-0.75))
  return(sigma_seq[target_index])
}
generate_synthetic_X <- function(X_obs, M) {
  apply(X_obs, 2, function(v) {
    u <- sample(v, size = M, replace = TRUE)
    if (length(unique(v)) <= 2) {
      ind <- sample(c(TRUE, FALSE), M, replace = TRUE)
      u[ind] <- rbinom(sum(ind), 1, 0.5)
    }else{
      sd_syn=get_sd_stdnormal(v)
      ind <- sample(c(TRUE, FALSE), M, replace = TRUE)
      u[ind] <- rnorm(sum(ind), mean = median(v), sd=sd_syn)
    }
    u
  })
  
}
# for each setting run independent experiment 50 times, for 
# each time we have three estimator: SRE_loocv, ridge_loocv, lasso_loocv
# we compare estimation error of these three estimators



# setting 1: n=100, p=100, kappa1=1, beta_true_gen="normal"
n=100
kappa1=1
tau_0_seq=seq(0.1,4,0.1)
M=1000
nrep=50 

error_matrix_p_mean=matrix(0,nrep,3)
error_matrix_p_std=matrix(0,nrep,3)
for(p in seq(50,200,by=10)){
  error_matrix=matrix(0,nrep,3)
  for(rep_i in 1:nrep){
    set.seed(2*rep_i)
    beta_true=generate_beta(p,kappa1,beta_true_gen="normal")/sqrt(p)*4
    X=matrix(rt(p*n,df=4)/sqrt(2),n,p)
    X[, 1] <- rbinom(n, 1, 0.9)
    X[, 3] <- rchisq(n,1)
    X[, 2] <- rchisq(n,4)
    
    
    Y=rbinom(n,1,1/(1+exp(-X%*%beta_true)))
    Xstar=generate_synthetic_X(X, M)
    beta0 = rep(0, p)
    Ystar = rbinom(M, 1, 1 / (1 + exp(-Xstar %*% beta0)))
    
    best_tau_0<-loocv_best_tau(X,Y,Xstar,Ystar,tau_0_seq)
    fit_cat_tau_0=glmnet(rbind(X,Xstar),c(Y,Ystar),weights =c(rep(1,n),rep(best_tau_0*n/M,M)) ,
                         family = "binomial",alpha=0,lambda = 0,intercept = FALSE,standardize = FALSE)
    SRE_loocv=as.numeric(fit_cat_tau_0$beta)
    fit_ridge_cv=cv.glmnet(X, Y, alpha = 0,family = "binomial" ,intercept = FALSE,standardize = FALSE)
    fit_lasso_cv=cv.glmnet(X, Y, alpha = 1,family = "binomial" ,intercept = FALSE,standardize = FALSE)
    ridge_loocv=as.numeric(predict(fit_ridge_cv,type="coef",s="lambda.min"))[-1]
    lasso_loocv=as.numeric(predict(fit_lasso_cv,type="coef",s="lambda.min"))[-1]
    
    error_matrix[rep_i,]=c(sum((SRE_loocv-beta_true)^2),sum((ridge_loocv-beta_true)^2),sum((lasso_loocv-beta_true)^2))
  }
  
  print(apply(error_matrix,2,mean))
  error_matrix_p_mean[(p-50)/10+1,]=apply(error_matrix,2,mean)
  error_matrix_p_std[(p-50)/10+1,]=apply(error_matrix,2,sd)/sqrt(nrep)
}
# save result for logistic regression
save(error_matrix_p_mean,file="error_matrix_p_mean_logistic.RData")
save(error_matrix_p_std,file="error_matrix_p_std_logistic.RData")





# now consider linear regression
# derive loocv for linear regression
sourceCpp("estimate_VE_linear.cpp")
loocv_best_tau_linear<-function(X,Y,Xstar,Ystar,tau_0_seq){
  p=ncol(X)
  n=length(Y)
  M=length(Ystar)
  ve_error=rep(0,length(tau_0_seq))
  for(tau_0_index in 1:length(tau_0_seq)){
    tau_0=tau_0_seq[tau_0_index]
    fit_cat_tau_0=glmnet(rbind(X,Xstar),c(Y,Ystar),weights =c(rep(1,n),rep(tau_0*n/M,M)) ,
                         alpha=0,lambda = 0,intercept = FALSE,standardize = FALSE)
                         
    betahat_tau0=as.numeric(fit_cat_tau_0$beta)
    ve_error[tau_0_index]=estimate_VELOOCV_cpp_po(X,Y,Xstar,Ystar,tau_0,betahat_tau0)
  }
  return(tau_0_seq[which.min(ve_error)])
}

n=100

kappa1=1
tau_0_seq=seq(0.01,4,0.1)
M=1000

error_matrix_p_mean=matrix(0,nrep,3)
error_matrix_p_std=matrix(0,nrep,3)
for(p in seq(50,200,by=10)){
  error_matrix=matrix(0,nrep,3)
  for(rep_i in 1:nrep){
    set.seed(2*rep_i)
    beta_true=generate_beta(p,kappa1,beta_true_gen="normal")/sqrt(p)*4
    X=matrix(rt(p*n,df=4)/sqrt(2),n,p)
    X[, 1] <- rbinom(n, 1, 0.9)
    X[, 3] <- rchisq(n,1)
    X[, 2] <- rchisq(n,4)
    Y= as.numeric(X %*% beta_true) + rnorm(n)
    Xstar=generate_synthetic_X(X, M)
    beta0 = rep(0, p)
    Ystar = as.numeric(Xstar %*% beta0) + rnorm(M)
    
    best_tau_0<-loocv_best_tau_linear(X,Y,Xstar,Ystar,tau_0_seq)
    fit_cat_tau_0=glmnet(rbind(X,Xstar),c(Y,Ystar),weights =c(rep(1,n),rep(best_tau_0*n/M,M)) ,
                         alpha=0,lambda = 0,intercept = FALSE,standardize = FALSE)
    SRE_loocv=as.numeric(fit_cat_tau_0$beta)
    fit_ridge_cv=cv.glmnet(X, Y, alpha = 0,intercept = FALSE,standardize = FALSE)
    fit_lasso_cv=cv.glmnet(X, Y, alpha = 1,intercept = FALSE,standardize = FALSE)
    ridge_loocv=as.numeric(predict(fit_ridge_cv,type="coef",s="lambda.min"))[-1]
    lasso_loocv=as.numeric(predict(fit_lasso_cv,type="coef",s="lambda.min"))[-1]
    
    error_matrix[rep_i,]=c(sum((SRE_loocv-beta_true)^2),sum((ridge_loocv-beta_true)^2),sum((lasso_loocv-beta_true)^2))
  }
  
  print(apply(error_matrix,2,mean))
  error_matrix_p_mean[(p-50)/10+1,]=apply(error_matrix,2,mean)
  error_matrix_p_std[(p-50)/10+1,]=apply(error_matrix,2,sd)/sqrt(nrep)
}
# save result for linea regression
save(error_matrix_p_mean,file="error_matrix_p_mean_linear.RData")
save(error_matrix_p_std,file="error_matrix_p_std_linear.RData")





# draw some plot
load("error_matrix_p_mean_logistic.RData")
load("error_matrix_p_std_logistic.RData")
p_seq=seq(50,200,by=10)
error_matrix_p_mean=error_matrix_p_mean[1:16,]
error_matrix_p_std=error_matrix_p_std[1:16,]
round(error_matrix_p_mean,3)
round(error_matrix_p_std,3)


load("error_matrix_p_mean_linear.RData")
load("error_matrix_p_std_linear.RData")
p_seq=seq(50,200,by=10)
error_matrix_p_mean=error_matrix_p_mean[1:16,]
error_matrix_p_std=error_matrix_p_std[1:16,]
round(error_matrix_p_mean,3)
round(error_matrix_p_std,3)



